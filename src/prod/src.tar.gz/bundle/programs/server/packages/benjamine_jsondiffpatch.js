(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['benjamine:jsondiffpatch'] = {};

})();

//# sourceMappingURL=benjamine_jsondiffpatch.js.map
